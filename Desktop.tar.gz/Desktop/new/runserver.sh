#!/bin/bash
cd 
cd /full path/project
# example: cd /home/rajeev/Desktop/new/project  (I have setup system in new directory)
./manage.py runserver 0.0.0.0:8181 &
