function numbersonly(e){
    var unicode=e.charCode? e.charCode : e.keyCode
    if (unicode!=8){ //if the key isn't the backspace key (which we should allow)
        if (unicode<48||unicode>57) //if not a number
            return false //disable key press
    }
}

function isAlphaNumeric(e)
         {
            var k;
            document.all ? k=e.keycode : k=e.which;
            return((k>47 && k<58)||(k>64 && k<91)||(k>96 && k<123)||k==0 || k==8);
         }


function Abbreviation(e)
         {
            var k;
            document.all ? k=e.keycode : k=e.which;
            return(((k>64 && k<91) || k==8);
         }


