import re
import csv

###############  Function to check all column filled values ###########



###############  Function end here                          ###########

###############  Function to check all column filled values ###########


###############  Function end here                          ###########


###############  Function to check unique column ###########

###############  Function end here                          ###########
	
###############  Function to validate total and mandetory ###########

###############  Function to check all column filled values ###########




###############  Function end here                          ###########
