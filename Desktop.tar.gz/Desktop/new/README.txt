=========================================================================================================================================
MIS for Blended MOOCs on IITBombayX

=========================================================================================================================================
This system will help teachers of engineering colleges in India for assessment of blended MOOCs. The teachers from various institutes participating in the blended MOOCs, will be able to generate a composite mark sheet for the particular course by giving certain weightage to online assessment along with their regular university assessment.

=========================================================================================================================================
Prerequisities:

To install the software following are the requirements:
Operating System: Ubuntu 12.04 and upper version
Software Required:
1) Django 1.8.2
2) MySQL-python 1.2.5
3) beautifulsoup4
4) Pillow 1.7.8

Database Required:
1)mysql-server-5.6

=========================================================================================================================================
Installing and running on your local machine:-

1)Enter college name in collegename.txt

2)Edit admin_info.conf and settings.py:

admin_info.conf (Enter value between double quotes) :
---------------
MySQL_PASSWORD (Default password:- MySQL_PASSWORD="123456")


settings.py (Enter value between double quotes) :
-----------
MySQL password at line no. 126 (Example:- 'PASSWORD': '123456' (same as MySQL_PASSWORD))

If use Moodle as LMS:
Moodle Database name at line no. 115 ('NAME': '')
MySQL password at line no. 117 ('PASSWORD': '')

3)Enter the full path in runserver.sh where you have setup the system.

4)Open terminal (Alt+Clt+t)

5)Now run following commands in the terminal:
-----------------------------------------
make
-----------------------------------------

6)Now go url in web browser:
-----------------------------------------
0.0.0.0:8181
-----------------------------------------

=========================================================================================================================================
Author:

    Rajeev Kumar Gautam 

=========================================================================================================================================
License


