#!/bin/bash
cd 
cd /home/rajeev/Desktop/new/project
./manage.py runserver 8000 &


